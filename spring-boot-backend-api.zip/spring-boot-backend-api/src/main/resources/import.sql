INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Fran', 'Grac�a', 'fran@iessanvicente.com', '2019-10-5');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Adrian', 'Villena', 'adrian@iessanvicente.com', '2019-09-20');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Roberto', 'tolon', 'rober@iessanvicente.com', '2019-05-15');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Daniel', 'Ruiz', 'dani@iessanvicente.com', '2019-07-18');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Jorge', 'Guerrero', 'jor@iessanvicente.com', '2019-12-16');
INSERT INTO clientes (nombre, apellido, email, create_at) VALUES ('Toni', 'Amas', 'toni@iessanvicente.com', '2019-03-17');