package com.adrian.springboot.backend.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBackendApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendApiApplication.class, args);
	}

}
