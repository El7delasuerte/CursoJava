package com.adrian.springboot.backend.api.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.adrian.springboot.backend.api.models.entity.Cliente;

public interface IclienteDAO extends CrudRepository<Cliente, Long> {

}
