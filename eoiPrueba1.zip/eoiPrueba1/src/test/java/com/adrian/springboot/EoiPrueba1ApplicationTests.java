package com.adrian.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EoiPrueba1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
