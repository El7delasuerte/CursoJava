package com.adrian.springboot.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/params")
public class RequestParamController {
	
	@GetMapping({"", "/"})
	public String index() {
		return "params/index";
	}
	
	//ejemplo Request param
	@GetMapping({"/string"})
	public String param(@RequestParam(name="texto", required=false, defaultValue="algún valor...") String texto, 
			@RequestParam(required=false) Integer numero, Model model) {
		model.addAttribute("resultado", "El texto es " + texto + "y el numero es: " + numero);
		return "params/ver";
	}
}
