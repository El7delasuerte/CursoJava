package com.adrian.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EoiPrueba1Application {

	public static void main(String[] args) {
		SpringApplication.run(EoiPrueba1Application.class, args);
	}

}
