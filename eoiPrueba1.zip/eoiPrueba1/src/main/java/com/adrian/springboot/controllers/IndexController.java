package com.adrian.springboot.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.adrian.springboot.models.Usuario;

@Controller
@RequestMapping("/app")
public class IndexController {
	
	@Value("@{texto.indexcontroller.index.titulo}")
	private String textoIndex;
	
	@Value("@{texto.indexcontroller.perfil.titulo}")
	private String textoPerfil;

	@GetMapping({"/index", "/"})
	public String index() {
		return "index";
	}
	
	@GetMapping("/perfil")
	public String perfil(Model model) {
		/*Usuario usuario = new Usuario();
		usuario.setNombre("Fran");
		usuario.setApellido("García");
		usuario.setEmail("garcia@gmail.com");
		model.addAttribute("usuarios", usuario);*/
		model.addAttribute("titulo", textoPerfil);
		return "perfil";
		
	}
	//Esto no es un endpoint
	//puede ser usada en todsa las vistas
	@ModelAttribute("usuarios")
	public List<Usuario> poblarUsuarios(){
		List<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios.add(new Usuario("Adrian","Villena","avillena@gmail.com"));
		usuarios.add(new Usuario("Roberto","Linares","rlinares@gmail.com"));
		usuarios.add(new Usuario("Alvaro","Ruiz","aruiz@gmail.com"));
		return usuarios;
	}
	
}
