package com.adrian.hibernate3;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


import com.adrian.hibernate3.Series;
import com.adrian.hibernate3.Televisiones;

/**
 * Hello world!
 *
 */
public class App 
{
	static SessionFactory sessionFactory = null;
	static Session session = null;
	static Scanner sc = new Scanner(System.in);
	public static void abrirConexion() {
		@SuppressWarnings("unused")
		org.jboss.logging.Logger logger = org.jboss.logging.Logger.getLogger("org.hibernate");
		java.util.logging.Logger.getLogger("org.hibernate").setLevel(java.util.logging.Level.SEVERE);
		sessionFactory = new Configuration().configure().buildSessionFactory();
		session = sessionFactory.openSession();
		if(session!=null) {
			System.out.println("Sesión abierta");
		} else {
			System.out.println("Fallo en la sesión");
		}
	}
	public static void cerrarConexion() {
		session.close();
	}
	public static void verSeries() {
		abrirConexion();
		Query<Series> consulta = session.createQuery("from Series");
		List<Series> resultados = consulta.list();

		for (Object resultado : resultados) {
			Series serie = (Series) resultado;
			System.out.println(serie.getCodSerie() + ": " + serie.getNombre() + ", de " 
			+ serie.getTelevisiones().getNombre() + " de " + serie.getDuracion() + " min");
		}
		cerrarConexion();
	}
	public static void insertarTele() {
		abrirConexion();
		System.out.println("Introduce el nombre");
    	String codigo = sc.nextLine();
    	sc.nextLine();
    	System.out.println("Introduce el nombre");
    	String nombre = sc.nextLine();
		Transaction trans = session.beginTransaction();
		Televisiones tele = new Televisiones(codigo,nombre,null);
		session.save(tele);
		trans.commit();
		cerrarConexion();
	}
	public static void insertarSerie() {
		abrirConexion();
		System.out.println("Introduce el codigo de la serie");
    	int codigoSerie = sc.nextInt();
    	sc.nextLine();
    	System.out.println("Introduce el Código de la cadena");
    	String codigo = sc.nextLine();
    	sc.nextLine();
    	System.out.println("Introduce el nombre");
    	String nombre = sc.nextLine();
    	sc.nextLine();
    	System.out.println("Introduce la duración de la serie");
    	int duracion = sc.nextInt();
		Transaction trans = session.beginTransaction();
		Series serie = new Series(codigoSerie,new Televisiones(codigo),nombre,duracion);
		session.save(serie);
		trans.commit();
		cerrarConexion();
	}
	public static void actualizarSerie() {
		abrirConexion();
		System.out.println("Introduce el nombre de la serie");
    	String codigo = sc.nextLine();
    	sc.nextLine();
    	System.out.println("Introduce el nombre de la serie actualizada");
    	String nombre = sc.nextLine();
        Query consulta = session.createQuery("FROM Series WHERE nombre='" + codigo + "'");
        List resultados = consulta.list();
        Transaction trans = session.beginTransaction();
        Series serieAModificar = (Series) resultados.get(0);
        serieAModificar.setNombre(nombre);
        session.update(serieAModificar);
		trans.commit();

		// Cerramos la sesión
		session.close();
	}
	public static void actualizarTele() {
		abrirConexion();
		System.out.println("Introduce el nombre de la cadena de television");
    	String codigo = sc.nextLine();
    	sc.nextLine();
    	System.out.println("Introduce el nombre de la cadena actualizada");
    	String nombre = sc.nextLine();
        Query consulta = session.createQuery("FROM Televisiones WHERE cod='" + codigo + "'");
        List resultados = consulta.list();
        Transaction trans = session.beginTransaction();
        Televisiones teleAModificar = (Televisiones) resultados.get(0);
        teleAModificar.setNombre(nombre);
        session.update(teleAModificar);
		trans.commit();

		// Cerramos la sesión
		session.close();
	}
	public static void borrarSerie() {
		abrirConexion();
		System.out.println("Introduce el código de la serie que quieres borrar");
    	String codigo = sc.nextLine();
    	String respuesta;
    	do {
    		System.out.println("Seguro que quieres borrar la serie con el codigo " + codigo);
    		respuesta = sc.nextLine();
         }
         while ( (!respuesta.equalsIgnoreCase("S")) && (!respuesta.equalsIgnoreCase("N")));
    	if(respuesta.equalsIgnoreCase("S")) {
    		Query consulta = session.createQuery("From Series WHERE cod_serie='" + codigo + "'");
    		List resultados = consulta.list();
    		Transaction trans = session.beginTransaction();
    		Series autoraBorrar = (Series) resultados.get(0);	
    		session.delete(autoraBorrar);
    		trans.commit();
    	}else {
    		System.out.println("No has borrado la serie");
    	}
		cerrarConexion();
}
	public static void borrarEspacios() {
		abrirConexion();
		int trim = session.createNativeQuery(
		"update series set nombre = trim(nombre)").executeUpdate();
		cerrarConexion();
	}
    public static void main( String[] args )
    {
    	Scanner sn = new Scanner(System.in);
        boolean salir = false;
        int opcion;
 
        while (!salir) {
 
            System.out.println("1. Ver Series");
            System.out.println("2. Insertar Cadena");
            System.out.println("3. Insertar Serie");
            System.out.println("4. Actualizar Serie");
            System.out.println("5. Actualizar Cadena");
            System.out.println("6. Borrar serie");
            System.out.println("7. Insertar Cadena");
            System.out.println("8. Insertar Serie");
            System.out.println("9. Actualizar Serie");
            System.out.println("10. Actualizar Cadena");
            System.out.println("10. Salir");
            try {
 
                System.out.println("Escribe una de las opciones");
                opcion = sn.nextInt();
 
                switch (opcion) {
                    case 1:
                        verSeries();
                        break;
                    case 2:
                    	insertarTele();
                        break;
                    case 3:
                    	insertarSerie();
                        break;
                    case 4:
                    	actualizarSerie();
                        break;
                    case 5:
                    	actualizarTele();
                        break;
                    case 6:
                    	verSeries();
                    	borrarSerie();
                    	verSeries();
                        break;
                    case 7:
                        borrarEspacios();
                        break;
                    case 8:
                    	insertarTele();
                        break;
                    case 9:
                    	insertarSerie();
                        break;
                    case 10:
                    	actualizarSerie();
                        break;
                    case 11:
                        salir = true;
                        break;
                    default:
                        System.out.println("Solo números entre 1 y 10");
                }
            } catch (InputMismatchException e) {
                System.out.println("Debes insertar un número");
                sn.next();
            }
        }
    }	
}
